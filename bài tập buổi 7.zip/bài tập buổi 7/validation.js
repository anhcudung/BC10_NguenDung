function soNguyenTo(n) {
  for (var i = 2; i <= n / 2; i++) {
    if (n % i === 0) {
      return;
    }
    return n;
  }
}
function phanChiaBai(n, m, arrA, arrB) {
  for (var i = n; i <= m; i += 4) {
    arrA.push(arrB[i]);
  }
}

