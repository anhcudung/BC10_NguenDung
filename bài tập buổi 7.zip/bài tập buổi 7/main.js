function getEle(id) {
  return document.getElementById(id);
}

// bài tập 1
console.log("BÀI TẬP 1");
function baiTap1() {
  var content = "";

  for (var i = 0; i < 10; i++) {
    for (var k = 1; k <= 10; k++) {
      content += i * 10 + k;
    }

    content += "\n";
  }
  console.log(content);
  // getEle("hinhvuong1").innerHTML = content;
}

console.log("----------------");
// hết bài tập 1

//bài tập 2

function timsoNT() {
  var list = [];
  var soNGuyen1 = +getEle("soNguyen1").value;
  var soNGuyen2 = +getEle("soNguyen2").value;
  var soNGuyen3 = +getEle("soNguyen3").value;
  var soNGuyen4 = +getEle("soNguyen4").value;

  list.push(soNguyenTo(soNGuyen1));
  list.push(soNguyenTo(soNGuyen2));
  list.push(soNguyenTo(soNGuyen3));
  list.push(soNguyenTo(soNGuyen4));
  console.log(list);
  getEle("nhungsoNT").innerHTML = list.join("--");
}
///hết bài 2

//bài tập 3
function tinhTongThamSoN() {
  var n = +getEle("songuyenN").value;
  var S = 2;
  for (var i = 3; i <= n; i++) {
    S += i;
  }

  getEle("tongThamSoN").innerHTML = S + 2 * n;
}
//hết bài 3

//bài tập 4
function tinhTongSoLuongUoc() {
  var dem = 0;
  var n = +getEle("songuyenNbt4").value;
  for (var i = 1; i <= n; i++) {
    if (n % i === 0) {
      dem++;
    }
  }
  getEle("tongLuongUoc").innerHTML = dem;
}
//hết bài 4

//bài số 5
function doiNguocSoNguyenDuong() {
  var n = getEle("songuyenNbt5").value;
  var m = [];
  for (var i = n.length - 1; i >= 0; i--) {
    m.push(n[i]);
  }
  n = m;

  getEle("daoNguocSo").innerHTML = n.join("");
}
//hết bài 5

// bài số 6
function soNguyenDuongBai6() {
  var n = [];
  var S = 0;
  for (var i = 1; i <= 50; i++) {
    S += i;
    if (S <= 100) {
      n.push(i);
    }
    getEle("soNguyenDuongBT6").innerHTML = n[n.length - 1];
  }
}
//hết bài số 6

// bài tập 7
function bangCuuChuong() {
  var total = "";
  var n = getEle("songuyenNbt7").value;
  for (i = 1; i <= 10; i++) {
    var d = n * i;
    // var b = "";
    total = total + n + "x" + i + "=" + d + "<br>";
  }
  getEle("bangcuuchuong").innerHTML = total;
}
//hết bài tập 7

//bài tập 8
function chiaBai() {
  var players = [[], [], [], []];
  var cards = [
    "4K",
    "KH",
    "5C",
    "KA",
    "QH",
    "KD",
    "2H",
    "10S",
    "AS",
    "7H",
    "9K",
    "10D",
  ];
  phanChiaBai(0, cards.length - 1, players[0], cards);
  phanChiaBai(1, cards.length - 1, players[1], cards);
  phanChiaBai(2, cards.length - 1, players[2], cards);
  phanChiaBai(3, cards.length - 1, players[3], cards);
  getEle("chiabai").innerHTML =
    "player1:" +
    players[0] +
    "<br>" +
    "player2:" +
    players[1] +
    "<br>" +
    "player3:" +
    players[2] +
    "<br>" +
    "player4:" +
    players[3] +
    "<br>";
  console.log(players[0]);
  console.log(players[1]);
  console.log(players[2]);
  console.log(players[3]);
}
//hết bài 8

//bài số 9
function gaCho() {
  n = +getEle("tongGaCho").value;
  m = +getEle("soChan").value;
  if (m % 2 !== 0 || m < n) {
    getEle("congbo").innerHTML =
      "VUI LÒNG NHẬP SỐ CHẴN Ở Ô TỔNG SỐ CHÂN VÀ PHẢI LỚN HƠN HOẶC BẰNG TỔNG SỐ CHÓ GÀ";
    return;
  }
  var ga = (4 * n - m) / 2;
  var cho = n - ga;
  getEle("congbo").innerHTML = "Số gà là :" + ga + "<br>" + " Số chó là:" + cho;
}
//hết bài 9

//bài số 10
//đơn vị ra độ (360 độ)
function gocGioPhut() {
  var gio = +getEle("soGio").value;
  var phut = +getEle("soPhut").value;
  var gocPhut = phut * 6; // trong 1 phút kim phút đi dc 6 độ
  var gocGio = gio * 30 + phut * 0.5; // trong 1 giờ kim giờ 30 độ cộng thêm số độ mà kim giờ đi được trong 1 phút là 0.5 độ.
  var gocLech = Math.abs(gocGio - gocPhut);
  getEle("goclech").innerHTML = "----" + gocLech + " độ" + "----";
}
//hết bài 10

// function gaCho() {
//   n = +getEle("tongGaCho").value;
//   m = +getEle("soChan").value;
//   for (var ga = 1; ga <= n; ga++) {
//     for (var cho = 1; cho <= n; cho++) {
//       if (cho + ga === n && cho * 4 + ga * 2 === m) {
//         ga = (4 * n - m) / 2;
//         cho = n - ga;

//         getEle("congbo").innerHTML =
//           "Số gà là :" + ga + "<br>" + " Số chó là:" + cho;
//       }
//       getEle("congbo").innerHTML =
//         "VUI LÒNG NHẬP SỐ CHẴN Ở Ô TỔNG SỐ CHÂN VÀ PHẢI LỚN HƠN HOẶC BẰNG TỔNG SỐ CHÓ GÀ";
//     }
//   }
// }
